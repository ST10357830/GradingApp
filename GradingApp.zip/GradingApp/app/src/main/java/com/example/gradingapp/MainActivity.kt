package com.example.gradingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private lateinit var studentNumberEditText: EditText
    private lateinit var studentNameEditText: EditText
    private lateinit var subjectEditText: EditText
    private lateinit var test1MarkEditText: EditText
    private lateinit var test2MarkEditText: EditText
    private lateinit var studentNumberTextView: TextView
    private lateinit var subjectTextView: TextView
    private lateinit var test1MarkTextView: TextView
    private lateinit var test2MarkTextView: TextView
    private lateinit var gradeTextView: TextView
    private lateinit var computeGradeButton: Button
    // Declare and initialize the TextViews
    private lateinit var studentNumberAnswerTextView: TextView
    private lateinit var subjectAnswerTextView: TextView
    private lateinit var test1MarkAnswerTextView: TextView
    private lateinit var test2MarkAnswerTextView: TextView
    private lateinit var gradeAnswerTextView: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Initialize UI elements
        studentNumberEditText = findViewById(R.id.studentNumberEditText)
        studentNameEditText = findViewById(R.id.studentNameEditText)
        subjectEditText = findViewById(R.id.subjectEditText)
        test1MarkEditText = findViewById(R.id.test1MarkEditText)
        test2MarkEditText = findViewById(R.id.test1MarkEditText)
        studentNumberTextView = findViewById(R.id.studentNumberTextView)
        subjectTextView = findViewById(R.id.subjectTextView)
        test1MarkTextView = findViewById(R.id.test1MarkTextView)
        test2MarkTextView = findViewById(R.id.test2MarkTextView)
        gradeTextView = findViewById(R.id.gradeTextView)
        computeGradeButton = findViewById(R.id.computeGradeButton)
        // Initialize the TextViews by finding them in the layout
        studentNumberAnswerTextView = findViewById(R.id.studentNumberAnswerTextView)
        subjectAnswerTextView = findViewById(R.id.subjectAnswerTextView)
        test1MarkAnswerTextView = findViewById(R.id.test1MarkAnswerTextView)
        test2MarkAnswerTextView = findViewById(R.id.test2MarkAnswerTextView)
        gradeAnswerTextView = findViewById(R.id.gradeAnswerTextView)


        computeGradeButton.setOnClickListener{
            //Get user input
            val studentNumber = studentNumberEditText.text.toString()
            val studentName = studentNameEditText.text.toString()
            val subject = subjectEditText.text.toString()
            val test1Mark = test1MarkEditText.text.toString().toFloatOrNull()
            val test2Mark = test2MarkEditText.text.toString().toFloatOrNull()



            //Checking if test results are valid
            if (test1Mark != null && test2Mark != null){

                //Calculating average
               val average = (test1Mark + test2Mark) /2

            //Determine grade
            val grade = when{
                average < 50 -> "FAIL"
                average in 50.0..74.0 -> "PASS"
                average in 75.0..100.0 -> "Distinction"
                else -> "INVALID"}

                // After calculating the results, update the answer TextViews
                studentNumberAnswerTextView.text = "$studentNumber"
                subjectAnswerTextView.text = "$subject"
                test1MarkAnswerTextView.text = "$test1Mark"
                test2MarkAnswerTextView.text = "$test2Mark"
                gradeAnswerTextView.text = "$grade"


            }else {
                gradeTextView.text = "Invalid input for test marks."
        }


        }
    }
}